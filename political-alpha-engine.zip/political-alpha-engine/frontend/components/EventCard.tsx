import type { AssetSignal } from "../lib/types";

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export default function EventCard({ signal }: { signal: AssetSignal }) {
  const bullish = signal.direction > 0;
  const color = bullish ? "var(--bullish)" : "var(--bearish)";

  return (
    <div
      style={{
        display: "flex",
        gap: 14,
        padding: "14px 16px",
        borderBottom: "1px solid var(--border)",
      }}
    >
      <div
        style={{
          width: 3,
          borderRadius: 2,
          background: color,
          flexShrink: 0,
        }}
      />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
          <span
            style={{
              fontFamily: "var(--font-mono)",
              fontWeight: 600,
              fontSize: 13,
              color: "var(--text-primary)",
            }}
          >
            {signal.asset}
          </span>
          <span
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: 12,
              color,
            }}
          >
            {bullish ? "▲" : "▼"} {(signal.direction * 100).toFixed(0)}%
          </span>
          <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--text-dim)" }}>
            {timeAgo(signal.driving_statement.published_at)}
          </span>
        </div>
        <div style={{ fontSize: 13, color: "var(--text-dim)", marginBottom: 6 }}>
          {signal.explanation}
        </div>
        <div
          style={{
            fontSize: 13,
            color: "var(--text-primary)",
            background: "var(--panel-alt)",
            borderLeft: "2px solid var(--amber-dim)",
            padding: "8px 10px",
            borderRadius: 3,
          }}
        >
          <span style={{ color: "var(--text-dim)" }}>
            {signal.driving_statement.speaker} ({signal.driving_statement.source}):
          </span>{" "}
          &ldquo;{signal.driving_statement.text}&rdquo;
        </div>
      </div>
    </div>
  );
}
