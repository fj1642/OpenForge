"use client";

/**
 * The signature visual of this dashboard: a horizontal analog-style gauge
 * running dovish (left) to hawkish (right), styled like a VU meter, with a
 * needle positioned by the statement's hawkish_dovish score. Width of the
 * needle's "glow" reflects certainty — a low-certainty hawkish statement
 * shows a wide, faint needle; a high-certainty one is thin and sharp.
 */
export default function StanceGauge({
  value,
  certainty,
  label,
}: {
  value: number; // -1 (dovish) to 1 (hawkish)
  certainty: number; // 0 to 1
  label?: string;
}) {
  const pct = ((value + 1) / 2) * 100;
  const blur = 6 - certainty * 5; // more blur = less certain

  return (
    <div style={{ width: "100%" }}>
      {label && (
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            color: "var(--text-dim)",
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            marginBottom: 6,
          }}
        >
          {label}
        </div>
      )}
      <div
        style={{
          position: "relative",
          height: 28,
          borderRadius: 4,
          background:
            "linear-gradient(90deg, var(--cyan) 0%, var(--panel-alt) 48%, var(--panel-alt) 52%, var(--amber) 100%)",
          border: "1px solid var(--border)",
          overflow: "visible",
        }}
      >
        {/* center tick */}
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: 0,
            bottom: 0,
            width: 1,
            background: "var(--border)",
          }}
        />
        {/* needle */}
        <div
          style={{
            position: "absolute",
            left: `calc(${pct}% - 2px)`,
            top: -4,
            bottom: -4,
            width: 4,
            borderRadius: 2,
            background: "var(--text-primary)",
            boxShadow: `0 0 ${blur}px 2px var(--text-primary)`,
            transition: "left 300ms ease",
          }}
        />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontFamily: "var(--font-mono)",
          fontSize: 10,
          color: "var(--text-dim)",
          marginTop: 4,
        }}
      >
        <span>DOVISH</span>
        <span>HAWKISH</span>
      </div>
    </div>
  );
}
