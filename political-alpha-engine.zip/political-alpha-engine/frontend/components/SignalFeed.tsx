import type { AssetSignal } from "../lib/types";
import EventCard from "./EventCard";

export default function SignalFeed({ signals }: { signals: AssetSignal[] }) {
  if (signals.length === 0) {
    return (
      <div style={{ padding: 24, color: "var(--text-dim)", fontSize: 13 }}>
        No signals yet. Once ingestion is running, new political and central-bank
        statements will appear here as they&apos;re scored.
      </div>
    );
  }
  return (
    <div>
      {signals.map((s, i) => (
        <EventCard key={i} signal={s} />
      ))}
    </div>
  );
}
