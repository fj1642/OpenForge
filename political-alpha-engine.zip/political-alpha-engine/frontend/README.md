# Frontend — Political Alpha Engine Dashboard

Next.js dashboard, deployable directly to Vercel.

## Local dev

```bash
npm install
npm run dev
```

Runs with mock data out of the box (see `app/api/signals/route.ts`) so you can
iterate on the UI before your backend/AMD pipeline is running.

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

Once your AMD-hosted FastAPI backend is running and tunneled (see
`../backend/README` section in the root README), set the env var in the
Vercel dashboard (Project Settings → Environment Variables):

```
BACKEND_URL=https://your-tunnel-url.example.com
```

Redeploy after setting it. Without it, the dashboard keeps serving mock data —
useful for demoing the UI in interviews without needing your home machine online.
