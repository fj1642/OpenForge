import { NextResponse } from "next/server";
import type { AssetSignal } from "../../../lib/types";

// Set BACKEND_URL as a Vercel env var once your AMD-hosted FastAPI service is
// tunneled/reachable. Until then, this route serves mock data so the
// dashboard is fully demoable on its own.
const BACKEND_URL = process.env.BACKEND_URL;

const MOCK_SIGNALS: AssetSignal[] = [
  {
    asset: "USD",
    direction: 0.62,
    confidence: 0.9,
    driving_statement: {
      source: "Federal Reserve",
      speaker: "Jerome Powell",
      text: "We will keep rates higher for longer until inflation is sustainably at target.",
      published_at: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    },
    explanation: "Bullish signal on USD driven by hawkish language (certainty=0.90)",
  },
  {
    asset: "GOLD",
    direction: -0.48,
    confidence: 0.9,
    driving_statement: {
      source: "Federal Reserve",
      speaker: "Jerome Powell",
      text: "We will keep rates higher for longer until inflation is sustainably at target.",
      published_at: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    },
    explanation: "Bearish signal on GOLD driven by hawkish language (certainty=0.90)",
  },
  {
    asset: "sector:steel_metals",
    direction: 0.55,
    confidence: 0.95,
    driving_statement: {
      source: "USTR",
      speaker: "US Trade Representative",
      text: "We will impose immediate tariffs on all imported steel and aluminum.",
      published_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    },
    explanation: "Bullish signal on sector:steel_metals driven by protectionist rhetoric (certainty=0.95)",
  },
  {
    asset: "sector:tech",
    direction: -0.21,
    confidence: 0.35,
    driving_statement: {
      source: "US Senate",
      speaker: "Senate Banking Committee",
      text: "This committee is exploring whether new antitrust legislation targeting large tech platforms is warranted.",
      published_at: new Date(Date.now() - 1000 * 60 * 200).toISOString(),
    },
    explanation: "Bearish signal on sector:tech driven by regulatory threat (certainty=0.35)",
  },
];

export async function GET(request: Request) {
  if (BACKEND_URL) {
    try {
      const { search } = new URL(request.url);
      const res = await fetch(`${BACKEND_URL}/signals${search}`, {
        next: { revalidate: 30 },
      });
      if (res.ok) {
        return NextResponse.json(await res.json());
      }
    } catch {
      // fall through to mock data if the AMD-hosted backend is unreachable
    }
  }
  return NextResponse.json(MOCK_SIGNALS);
}
