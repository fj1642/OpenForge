import StanceGauge from "../components/StanceGauge";
import SignalFeed from "../components/SignalFeed";
import type { AssetSignal } from "../lib/types";

async function getSignals(): Promise<AssetSignal[]> {
  const base = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000";
  const res = await fetch(`${base}/api/signals`, { cache: "no-store" });
  if (!res.ok) return [];
  return res.json();
}

export default async function Page() {
  const signals = await getSignals();
  const topSignal = signals[0];

  return (
    <main style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 20px 80px" }}>
      <header style={{ marginBottom: 32 }}>
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            color: "var(--amber)",
            letterSpacing: "0.12em",
            marginBottom: 6,
          }}
        >
          POLITICAL ALPHA ENGINE — RESEARCH SIGNALS ONLY, NOT EXECUTION
        </div>
        <h1
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 28,
            fontWeight: 700,
            margin: 0,
            letterSpacing: "-0.01em",
          }}
        >
          Macro Signal Feed
        </h1>
        <p style={{ color: "var(--text-dim)", fontSize: 14, marginTop: 8, maxWidth: 640 }}>
          Live-scored political and central-bank language, mapped to directional
          signals across FX, rates, and equity sectors. Every signal links back
          to the exact statement that produced it.
        </p>
      </header>

      {topSignal && (
        <section
          style={{
            background: "var(--panel)",
            border: "1px solid var(--border)",
            borderRadius: 6,
            padding: 20,
            marginBottom: 28,
          }}
        >
          <div
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: 11,
              color: "var(--text-dim)",
              letterSpacing: "0.08em",
              marginBottom: 14,
            }}
          >
            LATEST DRIVING STATEMENT
          </div>
          <StanceGauge
            value={
              topSignal.explanation.toLowerCase().includes("hawkish")
                ? topSignal.confidence
                : topSignal.explanation.toLowerCase().includes("dovish")
                ? -topSignal.confidence
                : 0
            }
            certainty={topSignal.confidence}
          />
        </section>
      )}

      <section
        style={{
          background: "var(--panel)",
          border: "1px solid var(--border)",
          borderRadius: 6,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            padding: "14px 16px",
            borderBottom: "1px solid var(--border)",
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            color: "var(--text-dim)",
            letterSpacing: "0.08em",
          }}
        >
          RECENT SIGNALS ({signals.length})
        </div>
        <SignalFeed signals={signals} />
      </section>

      <footer style={{ marginTop: 24, fontSize: 12, color: "var(--text-dim)" }}>
        Signals are hypotheses generated from language patterns, not validated
        trading recommendations. See the backtest results in the API before
        weighing any signal.
      </footer>
    </main>
  );
}
