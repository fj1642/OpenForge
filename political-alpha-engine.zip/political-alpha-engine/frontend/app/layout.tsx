import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Political Alpha Engine",
  description: "Macro signal research from political and central-bank language",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
