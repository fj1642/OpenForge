export interface RawStatement {
  source: string;
  speaker: string;
  text: string;
  published_at: string;
  url?: string;
}

export interface StanceScore {
  hawkish_dovish: number;
  protectionism: number;
  regulatory_threat: number;
  certainty: number;
  method: "classifier" | "llm_fallback" | "ground_truth_label";
  rationale?: string;
}

export interface AssetSignal {
  asset: string;
  direction: number;
  confidence: number;
  driving_statement: RawStatement;
  explanation: string;
}

export interface BacktestResult {
  asset: string;
  window_days: number;
  hit_rate: number;
  avg_move_pct_when_signal_fired: number;
  n_signals: number;
  sharpe_like_ratio: number | null;
}
