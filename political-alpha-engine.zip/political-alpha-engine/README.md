# Political Alpha Engine

A signal-research dashboard that reads political and central-bank language (Fed speeches,
congressional testimony, tariff announcements, campaign rhetoric) and converts it into
macro trading signals — with full backtested justification. **Signal-only: this system
does not place trades.**

## Why this design

Markets don't move on *what* a politician or central banker says — they move on shifts in
*how* they say it (hawkish → dovish drift, hedged vs. certain language, escalation vs.
de-escalation framing). Generic sentiment analysis (positive/negative) misses this entirely.
This engine is built around a **domain-specific stance taxonomy**, not generic sentiment.

## Architecture

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐     ┌────────────┐
│  Ingestion  │ --> │  Stance Engine   │ --> │  Signal Mapper  │ --> │ Dashboard  │
│  (Python)   │     │  (AMD box/ROCm)  │     │  + Backtester   │     │ (Next.js/  │
│             │     │                  │     │  (Python)       │     │  Vercel)   │
└─────────────┘     └──────────────────┘     └─────────────────┘     └────────────┘
     news APIs         classifier + LLM         historical corr         signal feed
     Fed calendar       fallback                  lookup table          + stance gauge
     congress.gov                                 vectorbt backtest     + backtest chart
```

**Key constraint that shapes everything:** Vercel has no GPU/NPU. Your AMD AI kit runs the
NLP inference layer on your own machine (or a small home server), exposed as a FastAPI
service. Vercel only hosts the Next.js dashboard, which calls that API (or reads
precomputed signals from a database if you want the dashboard to work even when your
machine is offline — recommended, see "Deployment" below).

## Stance taxonomy (the actual IP of this project)

Instead of positive/negative, every statement is scored on 4 independent axes:

| Axis | Range | What it captures |
|---|---|---|
| `hawkish_dovish` | -1.0 to 1.0 | Central bank tightening vs. easing language |
| `protectionism` | 0.0 to 1.0 | Tariff/trade-war rhetoric intensity |
| `regulatory_threat` | 0.0 to 1.0 | Sector-specific regulatory crackdown language |
| `certainty` | 0.0 to 1.0 | Hedged ("may consider") vs. committed ("will") framing |

`certainty` is a multiplier on the other three — a hawkish statement said with low
certainty should produce a weaker signal than the same statement said with conviction.
This is the detail most naive sentiment pipelines miss.

## AMD AI kit usage (recommended split)

1. **Primary: fine-tuned classifier** — Take a small encoder (DistilBERT or FinBERT base),
   fine-tune it on a labeled dataset of political/Fed statements → the 4 axes above.
   Runs fast on the AMD NPU/GPU via ONNX Runtime with the ROCm/DirectML execution
   provider — cheap enough to run on every headline in real time. This is what you
   backtest against and what gives you a defensible, reproducible signal.
2. **Fallback: local LLM via ROCm** — For statements the classifier flags as
   low-confidence (near-zero on all axes, or high linguistic complexity), route to a
   locally-hosted quantized model (Llama 3 8B or Mistral 7B, run via `llama.cpp` built
   with the ROCm backend, or `transformers` + `bitsandbytes` on ROCm) with a structured
   prompt asking it to score the same 4 axes and explain its reasoning. Slower, but only
   needed for the hard minority of cases.
3. Log every LLM-scored case with the classifier's original score — this becomes your
   next fine-tuning batch. The system should get cheaper to run over time.

See `backend/app/stance_model.py` for both paths implemented behind one interface.

## Repo layout

```
backend/            FastAPI service — runs on your AMD machine
  app/
    main.py          API entrypoint (/analyze, /signals, /backtest)
    stance_model.py  Classifier + LLM fallback (the AMD-hosted piece)
    schemas.py       Pydantic models
  ingestion/
    sources.py       Tracked speakers/feeds config
    news_fetcher.py  Pulls news + Fed calendar + congress.gov statements
  signals/
    mapper.py        Stance scores -> asset-class directional signals
  backtest/
    engine.py        Vectorized backtest of the stance->price-move hypothesis
    sample_run.py    Example run against included sample data
  data/
    sample_events.json   Labeled example events to get started
  requirements.txt
  Dockerfile

frontend/           Next.js app — deploys to Vercel
  app/page.tsx        Dashboard (signal feed, stance gauge, backtest chart)
  app/api/signals/route.ts   Reads from DB or proxies to your backend
  components/         StanceGauge, SignalFeed, EventCard
```

## Deployment

- **Backend**: run on your AMD box (bare metal or Docker, see `backend/Dockerfile`).
  Expose it via a reverse tunnel (Cloudflare Tunnel / Tailscale Funnel) so Vercel's
  serverless functions can reach it — do not open it directly to the internet.
- **Recommended production pattern**: backend writes computed signals to a small hosted
  Postgres (Supabase/Neon free tier), Next.js API routes just read from that DB. This way
  the dashboard stays live even if your AMD machine is off, and you avoid exposing your
  home network as a live API dependency.
- **Frontend**: `vercel deploy` from `frontend/`, set `DATABASE_URL` (or
  `BACKEND_URL` if you go with the direct-proxy pattern instead) as an env var.

## Honest limitations (say these out loud in interviews — it's a strength, not a weakness)

- Historical labeled data for "political statement -> market move" is thin and noisy;
  the backtest in `backtest/engine.py` is a hypothesis-testing tool, not proof of alpha.
- This is a **research signal generator**, not an execution system, on purpose — mixing
  unproven NLP signals with real capital is how you lose money and credibility.
- Stance taxonomy weights (`signals/mapper.py`) start as reasonable priors from
  documented Fed-speak studies, not fitted parameters — treat them as a v1 to refine once
  you have backtest results.
