from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class RawStatement(BaseModel):
    """A single piece of political/central-bank language to be scored."""
    source: str                      # e.g. "Federal Reserve", "White House", "Reuters"
    speaker: str                     # e.g. "Jerome Powell", "President", "Sen. X"
    text: str
    published_at: datetime
    url: Optional[str] = None


class StanceScore(BaseModel):
    """Output of the stance model for one statement."""
    hawkish_dovish: float = Field(..., ge=-1.0, le=1.0)
    protectionism: float = Field(..., ge=0.0, le=1.0)
    regulatory_threat: float = Field(..., ge=0.0, le=1.0)
    certainty: float = Field(..., ge=0.0, le=1.0)
    method: str                      # "classifier" or "llm_fallback"
    rationale: Optional[str] = None  # only populated for llm_fallback


class ScoredStatement(BaseModel):
    statement: RawStatement
    scores: StanceScore


class AssetSignal(BaseModel):
    asset: str                       # e.g. "USD", "US10Y", "SPX", "sector:tech"
    direction: float = Field(..., ge=-1.0, le=1.0)  # -1 bearish ... +1 bullish
    confidence: float = Field(..., ge=0.0, le=1.0)
    driving_statement: RawStatement
    explanation: str


class BacktestResult(BaseModel):
    asset: str
    window_days: int
    hit_rate: float
    avg_move_pct_when_signal_fired: float
    n_signals: int
    sharpe_like_ratio: Optional[float] = None
