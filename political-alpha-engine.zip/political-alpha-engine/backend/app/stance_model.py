"""
Stance scoring engine — the piece that runs on your AMD AI kit.

Two paths behind one interface:
  1. `ClassifierStance`  — fast fine-tuned encoder, runs via ONNX Runtime.
     This is what you should run on every incoming statement.
  2. `LLMFallbackStance` — local quantized LLM via llama.cpp (ROCm backend),
     used only when the classifier is low-confidence.

Neither path calls an external API — everything here runs on your own hardware,
which is the whole point of using the AMD kit (cost + latency at scale, and no
vendor dependency for a production signal pipeline).
"""
from __future__ import annotations
import json
import re
from typing import Optional

from .schemas import StanceScore

# ---------------------------------------------------------------------------
# 1. Classifier path (primary)
# ---------------------------------------------------------------------------
#
# Training data: label a few thousand historical Fed/political statements with
# the 4 axes (see backend/data/sample_events.json for the label schema — start
# there, then expand). Fine-tune with a standard HF Trainer script (not
# included here since it's a one-time offline job, not part of the serving
# path), export to ONNX, and drop the .onnx file in backend/app/models/.
#
# To export a fine-tuned HF model to ONNX for AMD/ROCm inference:
#   optimum-cli export onnx --model ./my-finetuned-stance-model ./models/stance-onnx
#
# Then load it with onnxruntime using the ROCm execution provider:
#   providers=["ROCMExecutionProvider", "CPUExecutionProvider"]

class ClassifierStance:
    def __init__(self, model_dir: str = "app/models/stance-onnx"):
        self.model_dir = model_dir
        self._session = None
        self._tokenizer = None

    def _lazy_load(self):
        if self._session is not None:
            return
        import onnxruntime as ort
        from transformers import AutoTokenizer

        providers = ["ROCMExecutionProvider", "CPUExecutionProvider"]
        self._session = ort.InferenceSession(
            f"{self.model_dir}/model.onnx", providers=providers
        )
        self._tokenizer = AutoTokenizer.from_pretrained(self.model_dir)

    def score(self, text: str) -> tuple[StanceScore, float]:
        """Returns (score, confidence). Confidence below THRESHOLD triggers LLM fallback."""
        self._lazy_load()
        inputs = self._tokenizer(text, return_tensors="np", truncation=True, max_length=512)
        ort_inputs = {k: v for k, v in inputs.items() if k in
                      [i.name for i in self._session.get_inputs()]}
        outputs = self._session.run(None, ort_inputs)
        # Expect the fine-tuned head to output 4 regression values + 1 confidence logit.
        # Adjust indices to match your actual fine-tuned model's output layout.
        raw = outputs[0][0]
        hawkish_dovish, protectionism, regulatory_threat, certainty, confidence = raw[:5]

        score = StanceScore(
            hawkish_dovish=float(max(-1.0, min(1.0, hawkish_dovish))),
            protectionism=float(max(0.0, min(1.0, protectionism))),
            regulatory_threat=float(max(0.0, min(1.0, regulatory_threat))),
            certainty=float(max(0.0, min(1.0, certainty))),
            method="classifier",
        )
        return score, float(confidence)


# ---------------------------------------------------------------------------
# 2. LLM fallback path (hard cases only)
# ---------------------------------------------------------------------------
#
# Build llama.cpp with the ROCm backend:
#   CMAKE_ARGS="-DLLAMA_HIPBLAS=on" pip install llama-cpp-python --no-cache-dir
# Download a quantized model, e.g. Meta-Llama-3-8B-Instruct.Q4_K_M.gguf, into
# backend/app/models/.

STANCE_PROMPT = """You are a financial-markets analyst scoring political/central-bank \
statements for trading-relevant language patterns. Score the statement below on 4 axes.

Statement: "{text}"

Respond with ONLY a JSON object, no other text:
{{
  "hawkish_dovish": <float -1.0 to 1.0, negative=dovish/easing, positive=hawkish/tightening, 0 if not monetary policy related>,
  "protectionism": <float 0.0 to 1.0, tariff/trade-war rhetoric intensity>,
  "regulatory_threat": <float 0.0 to 1.0, sector regulatory crackdown intensity>,
  "certainty": <float 0.0 to 1.0, how committed vs. hedged the language is>,
  "rationale": "<one sentence explaining the score, quoting the key phrase>"
}}"""


class LLMFallbackStance:
    def __init__(self, model_path: str = "app/models/llama-3-8b-instruct.Q4_K_M.gguf"):
        self.model_path = model_path
        self._llm = None

    def _lazy_load(self):
        if self._llm is not None:
            return
        from llama_cpp import Llama
        self._llm = Llama(
            model_path=self.model_path,
            n_gpu_layers=-1,   # offload all layers to the AMD GPU via ROCm/HIP build
            n_ctx=2048,
        )

    def score(self, text: str) -> StanceScore:
        self._lazy_load()
        prompt = STANCE_PROMPT.format(text=text)
        result = self._llm(prompt, max_tokens=300, temperature=0.1, stop=["}"])
        raw_text = result["choices"][0]["text"] + "}"
        parsed = self._extract_json(raw_text)

        return StanceScore(
            hawkish_dovish=float(parsed.get("hawkish_dovish", 0.0)),
            protectionism=float(parsed.get("protectionism", 0.0)),
            regulatory_threat=float(parsed.get("regulatory_threat", 0.0)),
            certainty=float(parsed.get("certainty", 0.5)),
            method="llm_fallback",
            rationale=parsed.get("rationale"),
        )

    @staticmethod
    def _extract_json(raw_text: str) -> dict:
        match = re.search(r"\{.*\}", raw_text, re.DOTALL)
        if not match:
            return {}
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return {}


# ---------------------------------------------------------------------------
# Unified interface used by app/main.py
# ---------------------------------------------------------------------------

CONFIDENCE_THRESHOLD = 0.55


class StanceEngine:
    def __init__(self):
        self.classifier = ClassifierStance()
        self.llm_fallback = LLMFallbackStance()

    def analyze(self, text: str) -> StanceScore:
        try:
            score, confidence = self.classifier.score(text)
            if confidence >= CONFIDENCE_THRESHOLD:
                return score
        except FileNotFoundError:
            # No fine-tuned model exported yet — fall straight through to the LLM path
            # so the API is usable before you've trained the classifier.
            pass
        return self.llm_fallback.score(text)
