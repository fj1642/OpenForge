"""
FastAPI service — run this on your AMD machine:

    uvicorn app.main:app --host 0.0.0.0 --port 8000

Expose it to your Vercel-hosted frontend via a Cloudflare Tunnel or Tailscale
Funnel rather than opening the port directly to the internet.
"""
from __future__ import annotations
from datetime import datetime
from typing import List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .schemas import RawStatement, ScoredStatement, AssetSignal, BacktestResult
from .stance_model import StanceEngine
from ..signals.mapper import map_statement_to_signals
from ..backtest.engine import run_event_study, signals_to_events

app = FastAPI(title="Political Alpha Engine", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your Vercel domain before going further than a prototype
    allow_methods=["*"],
    allow_headers=["*"],
)

stance_engine = StanceEngine()

# In-memory store for the prototype — swap for Postgres (see README) once
# you want the dashboard to stay live independent of this process.
_recent_signals: List[AssetSignal] = []


@app.post("/analyze", response_model=ScoredStatement)
def analyze_statement(statement: RawStatement):
    try:
        scores = stance_engine.analyze(statement.text)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Stance model error: {exc}")

    signals = map_statement_to_signals(statement, scores)
    _recent_signals.extend(signals)
    _recent_signals[:] = _recent_signals[-500:]  # cap memory in the prototype

    return ScoredStatement(statement=statement, scores=scores)


@app.get("/signals", response_model=List[AssetSignal])
def get_recent_signals(asset: str | None = None, limit: int = 50):
    signals = _recent_signals
    if asset:
        signals = [s for s in signals if s.asset == asset]
    return signals[-limit:]


@app.get("/backtest", response_model=List[BacktestResult])
def get_backtest(window_days: int = 3):
    if not _recent_signals:
        return []
    events = signals_to_events(_recent_signals)
    return run_event_study(events, window_days=window_days)


@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}
