"""
Pulls raw statements from configured sources and normalizes them into
RawStatement objects for the stance engine.

Run standalone (`python -m ingestion.news_fetcher`) to poll once, or import
`fetch_all()` and schedule it (cron / APScheduler) for continuous ingestion.
"""
from __future__ import annotations
from datetime import datetime
from typing import List

import requests

from .sources import NEWS_API_KEY, NEWS_API_BASE_URL, NEWS_QUERY_TERMS
from ..app.schemas import RawStatement


def fetch_news(query_terms: List[str] = NEWS_QUERY_TERMS, page_size: int = 20) -> List[RawStatement]:
    if not NEWS_API_KEY:
        raise RuntimeError(
            "NEWS_API_KEY not set. Get a free key at newsapi.org and set it as an "
            "environment variable before running ingestion."
        )

    statements: List[RawStatement] = []
    for term in query_terms:
        resp = requests.get(
            NEWS_API_BASE_URL,
            params={
                "q": term,
                "apiKey": NEWS_API_KEY,
                "language": "en",
                "sortBy": "publishedAt",
                "pageSize": page_size,
            },
            timeout=10,
        )
        resp.raise_for_status()
        for article in resp.json().get("articles", []):
            statements.append(RawStatement(
                source=article["source"]["name"],
                speaker=article.get("author") or article["source"]["name"],
                text=f"{article['title']}. {article.get('description') or ''}".strip(),
                published_at=datetime.fromisoformat(article["publishedAt"].replace("Z", "+00:00")),
                url=article.get("url"),
            ))
    return statements


def fetch_fed_calendar() -> List[RawStatement]:
    """
    The Fed calendar endpoint gives scheduled speeches/events, not transcripts.
    Use this to know WHEN to watch for a statement; pair with a transcript
    scraper (e.g. federalreserve.gov press release pages) for the actual text.
    This stub returns an empty list — wire up the transcript scraper for your
    specific tracked speakers in sources.py before relying on this in production.
    """
    return []


def fetch_all() -> List[RawStatement]:
    statements = []
    statements.extend(fetch_news())
    statements.extend(fetch_fed_calendar())
    return statements


if __name__ == "__main__":
    results = fetch_all()
    print(f"Fetched {len(results)} statements")
    for s in results[:5]:
        print(f"- [{s.source}] {s.text[:100]}")
