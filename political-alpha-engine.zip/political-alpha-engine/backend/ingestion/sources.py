"""
Config of sources this engine polls. Add API keys via environment variables,
never hardcode them.
"""
import os

NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")
CONGRESS_GOV_API_KEY = os.getenv("CONGRESS_GOV_API_KEY", "")

TRACKED_SPEAKERS = [
    # Central bank — highest signal density for hawkish/dovish axis
    {"name": "Jerome Powell", "role": "Fed Chair", "source": "Federal Reserve"},
    {"name": "FOMC", "role": "committee", "source": "Federal Reserve"},
    {"name": "Christine Lagarde", "role": "ECB President", "source": "ECB"},
    # Executive/trade — highest signal density for protectionism axis
    {"name": "US Trade Representative", "role": "USTR", "source": "USTR"},
    {"name": "Treasury Secretary", "role": "Treasury", "source": "US Treasury"},
    # Congress — regulatory_threat axis, sector-specific
    {"name": "Senate Banking Committee", "role": "committee", "source": "US Senate"},
    {"name": "House Financial Services Committee", "role": "committee", "source": "US House"},
]

NEWS_QUERY_TERMS = [
    "Federal Reserve", "FOMC", "interest rates", "tariff", "trade war",
    "antitrust", "regulation", "sanctions", "Treasury Secretary",
]

FED_CALENDAR_URL = "https://www.federalreserve.gov/json/calendar.json"
CONGRESS_GOV_BASE_URL = "https://api.congress.gov/v3"
NEWS_API_BASE_URL = "https://newsapi.org/v2/everything"
