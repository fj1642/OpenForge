"""
Tests the core hypothesis: "does a stance-derived signal on asset X precede a
real, directionally-consistent price move in X?"

This is intentionally simple (event study, not a full portfolio backtest) —
the goal is to validate the NLP signal itself before building any execution
logic on top of it. Don't skip this step; an unvalidated NLP signal is a
guess with extra steps.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

import numpy as np
import pandas as pd
import yfinance as yf

from ..app.schemas import AssetSignal, BacktestResult

# Map our internal asset names to tickers yfinance understands
TICKER_MAP = {
    "USD": "DX-Y.NYB",
    "US10Y": "^TNX",
    "GOLD": "GC=F",
    "SPX": "^GSPC",
    "sector:tech": "XLK",
    "sector:industrials": "XLI",
    "sector:steel_metals": "SLX",
}


@dataclass
class SignalEvent:
    asset: str
    date: pd.Timestamp
    direction: float  # -1..1, sign is the predicted move direction


def run_event_study(events: List[SignalEvent], window_days: int = 3) -> List[BacktestResult]:
    """
    For each asset, pull price history once, then for every signal event check
    whether price moved in the predicted direction over the following
    `window_days` trading days.
    """
    results: List[BacktestResult] = []
    by_asset: dict[str, List[SignalEvent]] = {}
    for e in events:
        by_asset.setdefault(e.asset, []).append(e)

    for asset, asset_events in by_asset.items():
        ticker = TICKER_MAP.get(asset)
        if not ticker:
            continue

        start = min(e.date for e in asset_events) - pd.Timedelta(days=5)
        end = max(e.date for e in asset_events) + pd.Timedelta(days=window_days + 5)
        prices = yf.download(ticker, start=start, end=end, progress=False)["Close"]
        if prices.empty:
            continue

        hits = 0
        moves = []
        for e in asset_events:
            entry_idx = prices.index.searchsorted(e.date)
            exit_idx = entry_idx + window_days
            if exit_idx >= len(prices):
                continue
            entry_price = prices.iloc[entry_idx]
            exit_price = prices.iloc[exit_idx]
            pct_move = (exit_price - entry_price) / entry_price

            predicted_up = e.direction > 0
            actual_up = pct_move > 0
            if predicted_up == actual_up:
                hits += 1
            moves.append(pct_move if predicted_up else -pct_move)

        n = len(moves)
        if n == 0:
            continue

        avg_move = float(np.mean(moves))
        std_move = float(np.std(moves)) if n > 1 else 0.0
        sharpe_like = (avg_move / std_move) if std_move > 0 else None

        results.append(BacktestResult(
            asset=asset,
            window_days=window_days,
            hit_rate=hits / n,
            avg_move_pct_when_signal_fired=avg_move,
            n_signals=n,
            sharpe_like_ratio=sharpe_like,
        ))

    return results


def signals_to_events(signals: List[AssetSignal]) -> List[SignalEvent]:
    return [
        SignalEvent(
            asset=s.asset,
            date=pd.Timestamp(s.driving_statement.published_at),
            direction=s.direction,
        )
        for s in signals
    ]
