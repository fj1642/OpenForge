"""
End-to-end smoke test using the bundled sample_events.json — run this first,
before wiring up live ingestion, to confirm the whole pipeline works:

    python -m backtest.sample_run
"""
import json
from datetime import datetime
from pathlib import Path

from ..app.schemas import RawStatement, StanceScore
from ..signals.mapper import map_statement_to_signals
from .engine import run_event_study, signals_to_events

SAMPLE_PATH = Path(__file__).parent.parent / "data" / "sample_events.json"


def main():
    raw = json.loads(SAMPLE_PATH.read_text())
    all_signals = []

    for item in raw:
        statement = RawStatement(
            source=item["source"],
            speaker=item["speaker"],
            text=item["text"],
            published_at=datetime.fromisoformat(item["published_at"].replace("Z", "+00:00")),
        )
        # Using the ground-truth labels directly here instead of the stance
        # model, since this script validates the mapper + backtest, not the
        # NLP layer. Swap in `StanceEngine().analyze(statement.text)` once
        # you've exported a fine-tuned classifier.
        scores = StanceScore(**item["labels"], method="ground_truth_label")
        signals = map_statement_to_signals(statement, scores)
        all_signals.extend(signals)
        for s in signals:
            print(f"  {s.asset:20s} dir={s.direction:+.2f}  {s.explanation}")

    print(f"\nGenerated {len(all_signals)} signals from {len(raw)} statements.\n")

    events = signals_to_events(all_signals)
    results = run_event_study(events, window_days=3)

    print("Backtest results (event study, 3-day forward window):")
    for r in results:
        print(
            f"  {r.asset:20s} hit_rate={r.hit_rate:.0%}  "
            f"avg_move={r.avg_move_pct_when_signal_fired:+.2%}  n={r.n_signals}"
        )


if __name__ == "__main__":
    main()
