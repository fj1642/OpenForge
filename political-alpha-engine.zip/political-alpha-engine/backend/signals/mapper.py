"""
Maps stance scores to directional signals per asset class.

The weights below are documented priors from Fed-communication research
(e.g. hawkish surprises strengthening USD and lifting yields), NOT fitted
parameters. Treat this file as v1 — once backend/backtest/engine.py has run
against real history, replace these constants with fitted coefficients.
"""
from __future__ import annotations
from ..app.schemas import StanceScore, RawStatement, AssetSignal

# (asset, weight-per-axis) — weight direction encodes the expected asset response
# to a +1 move in that axis, all else equal.
ASSET_SENSITIVITY = {
    "USD":        {"hawkish_dovish": 0.7,  "protectionism": 0.1,  "regulatory_threat": 0.0},
    "US10Y":      {"hawkish_dovish": 0.8,  "protectionism": 0.0,  "regulatory_threat": 0.0},
    "GOLD":       {"hawkish_dovish": -0.6, "protectionism": 0.2,  "regulatory_threat": 0.0},
    "SPX":        {"hawkish_dovish": -0.4, "protectionism": -0.3, "regulatory_threat": -0.2},
    "sector:tech":     {"hawkish_dovish": -0.3, "protectionism": -0.2, "regulatory_threat": -0.7},
    "sector:industrials": {"hawkish_dovish": -0.2, "protectionism": -0.6, "regulatory_threat": -0.1},
    "sector:steel_metals": {"hawkish_dovish": 0.0, "protectionism": 0.6,  "regulatory_threat": -0.1},
}


def map_statement_to_signals(statement: RawStatement, scores: StanceScore) -> list[AssetSignal]:
    signals: list[AssetSignal] = []
    for asset, weights in ASSET_SENSITIVITY.items():
        raw_direction = (
            weights["hawkish_dovish"] * scores.hawkish_dovish
            + weights["protectionism"] * scores.protectionism
            + weights["regulatory_threat"] * scores.regulatory_threat
        )
        # certainty scales the magnitude, not the sign
        direction = max(-1.0, min(1.0, raw_direction * scores.certainty))

        if abs(direction) < 0.05:
            continue  # not worth surfacing as a signal

        signals.append(AssetSignal(
            asset=asset,
            direction=direction,
            confidence=scores.certainty,
            driving_statement=statement,
            explanation=_explain(asset, scores, direction),
        ))
    return signals


def _explain(asset: str, scores: StanceScore, direction: float) -> str:
    tone = "bullish" if direction > 0 else "bearish"
    drivers = []
    if abs(scores.hawkish_dovish) > 0.2:
        drivers.append("hawkish" if scores.hawkish_dovish > 0 else "dovish")
    if scores.protectionism > 0.2:
        drivers.append("protectionist rhetoric")
    if scores.regulatory_threat > 0.2:
        drivers.append("regulatory threat")
    driver_str = ", ".join(drivers) if drivers else "mixed language"
    return f"{tone.capitalize()} signal on {asset} driven by {driver_str} (certainty={scores.certainty:.2f})"
